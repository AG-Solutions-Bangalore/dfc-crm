const BASE_URL = "https://agsl.online/public";


export default BASE_URL;





